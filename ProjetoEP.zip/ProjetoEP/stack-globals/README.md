# stack-globals
